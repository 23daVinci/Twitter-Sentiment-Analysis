# -*- coding: utf-8 -*-
import sentiment_mod as s

print(s.sentiment("I think the movie was a masterpiece, filled with scenes that will keep you on the edge of your seats. I will give it 8/10"))

print(s.sentiment("This movie was pathetic, not worth your money. Don't go for this movie. Waste of money!! Even the scenes were poorly directed."))
